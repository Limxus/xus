package test;

import game.Ui;
import mob.Beukein;
import mob.Bulkkochsung;
import mob.Ingaking;
import mob.Jiririball;
import mob.Jupythunder;
import mob.Kobugi;
import mob.Pairi;
import mob.Pikachu;
import mob.Pokemon;
import mob.Yadon;

public class Test {

//	public static void main(String[] args) throws InterruptedException {
//		// TODO Auto-generated method stub
//
//		Pokemon p = new Pokemon();
//		
//		Pikachu pika = new Pikachu("피카츄");
//		Pairi pai = new Pairi("파이리");
//		Kobugi kobu = new Kobugi("꼬부기");
//		Beukein beuke = new Beukein("브케인");
//		Bulkkochsung bulsung = new Bulkkochsung("불꽃숭이");
//		Ingaking ingaking = new Ingaking("잉어킹");
//		Jiririball jiriri = new Jiririball("찌리리공");
//		Jupythunder jupy = new Jupythunder("쥬피썬더");
//		Yadon yadon = new Yadon("야돈");
//		
//		Ui ui = new Ui();
//
//		ui.grase();
//	}
	

}
