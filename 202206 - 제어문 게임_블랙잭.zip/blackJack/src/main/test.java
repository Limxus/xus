package main;

public class test {
	public static void main(String[] args) {
		
		String a = "asdf";
		String b = a.substring(-1);
		
		System.out.println(b);
				
	}
	

}
