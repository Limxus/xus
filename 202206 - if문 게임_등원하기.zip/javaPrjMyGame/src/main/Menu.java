package main;

public class Menu {
	
	public void wd(String text1, String text2, String text3, String text4) {
		System.out.println("----------------------------------------");
		System.out.println("    "+text1);
		System.out.println("    "+text2);
		System.out.println("    "+text3);
		System.out.println("    "+text4);
		System.out.println("----------------------------------------");
		System.out.println("----------------------------------------");
		System.out.print("당신의 선택은??    >>> ");
	}
	
	public void wdMs(String text1) {
		System.out.println("========================================");
		System.out.println(text1);
		System.out.println("========================================");
	}

}
